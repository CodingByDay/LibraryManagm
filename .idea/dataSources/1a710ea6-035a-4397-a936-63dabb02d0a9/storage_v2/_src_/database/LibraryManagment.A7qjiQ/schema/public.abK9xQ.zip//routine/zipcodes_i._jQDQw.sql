create function zipcodes_i(i_zipcodes integer, i_zipcode character varying, i_city character varying) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('zipcodes_id_zipcodes_seq');
        -- izvršimo INSERT stavek
        INSERT INTO zipcodes(id_zipcodes, zipcode, city)
        VALUES (kljuc, i_zipcode, i_city);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function zipcodes_i(integer, varchar, varchar) owner to postgres;

