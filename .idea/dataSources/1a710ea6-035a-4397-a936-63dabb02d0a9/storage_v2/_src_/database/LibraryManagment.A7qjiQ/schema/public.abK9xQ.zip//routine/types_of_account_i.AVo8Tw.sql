create function types_of_account_i(i_types_of_account character varying) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('types_of_account_id_types_of_account_seq');
        -- izvršimo INSERT stavek
        INSERT INTO types_of_account(id_types_of_account, type_of_account)
        VALUES (kljuc, i_types_of_account);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function types_of_account_i(varchar) owner to postgres;

