create function loan_book_detail_i(i_id_loan integer, i_id_book_items integer, i_from date, i_due date, i_return_date date, i_id_reservation integer) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('loan_book_detail_id_loan_book_detail_seq');
        -- izvršimo INSERT stavek
        INSERT INTO loan_book_detail
        VALUES (kljuc, i_id_loan, i_id_book_items, i_from, i_due, i_return_date, i_id_reservation);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function loan_book_detail_i(integer, integer, date, date, date, integer) owner to postgres;

