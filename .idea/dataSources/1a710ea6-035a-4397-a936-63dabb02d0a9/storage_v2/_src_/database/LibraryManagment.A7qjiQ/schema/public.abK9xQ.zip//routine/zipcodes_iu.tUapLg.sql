create function zipcodes_iu(i_id_zipcodes integer, i_zipcode character varying, i_city character varying) returns integer
    language plpgsql
as
$$
DECLARE
    kljuc INTEGER;
BEGIN
    IF (i_id_zipcodes IS NULL) THEN
    BEGIN
        -- uporabimo naslednjo vrednost seqvence
        kljuc = nextval('zipcodes_id_zipcodes_seq');
        -- izvršimo INSERT stavek
        INSERT INTO zipcodes(id_zipcodes, zipcode, city) VALUES (kljuc, i_zipcode, i_city);
        -- prestrezanje možnih izjem
        EXCEPTION
            WHEN integrity_constraint_violation THEN
                RAISE EXCEPTION 'Napaka ... referenčna integriteta.';
            WHEN not_null_violation THEN
                RAISE EXCEPTION 'Napaka ... ni zahtevane vrednosti polja.';
            WHEN foreign_key_violation THEN
                RAISE EXCEPTION 'Napaka ... neustrezna vrednost tujega ključa.';
            WHEN unique_violation THEN
                RAISE EXCEPTION 'Napaka ... ni enolične vrednosti polja.';
            WHEN check_violation THEN
                RAISE EXCEPTION 'Napaka ... validacijsko pravilo.';
            WHEN string_data_right_truncation THEN
                RAISE EXCEPTION 'Napaka ... vrednost vsebuje več znakov kot je dolžina polja.';
            -- v primeru ostalih napak
            WHEN others THEN
                RAISE EXCEPTION 'Napaka ...';
        END;
    ELSE
    BEGIN
        -- izvršimo UPDATE stavek
        UPDATE zipcodes
            SET
                zipcode = i_zipcode,
                city = i_city
            WHERE id_zipcodes = i_id_zipcodes;
        kljuc = i_id_zipcodes;
        -- prestrezanje možnih izjem
         EXCEPTION
            WHEN integrity_constraint_violation THEN
                RAISE EXCEPTION 'Napaka ... referenčna integriteta.';
            WHEN not_null_violation THEN
                RAISE EXCEPTION 'Napaka ... ni zahtevane vrednosti polja.';
            WHEN foreign_key_violation THEN
                RAISE EXCEPTION 'Napaka ... neustrezna vrednost tujega ključa.';
            WHEN unique_violation THEN
                RAISE EXCEPTION 'Napaka ... ni enolične vrednosti polja.';
            WHEN check_violation THEN
                RAISE EXCEPTION 'Napaka ... validacijsko pravilo.';
            WHEN string_data_right_truncation THEN
                RAISE EXCEPTION 'Napaka ... vrednost vsebuje več znakov kot je dolžina polja.';
                -- v primeru ostalih napak
                WHEN others THEN
                RAISE EXCEPTION 'Napaka ...';
    END;
    END IF;
    RETURN kljuc;
END;
$$;

alter function zipcodes_iu(integer, varchar, varchar) owner to postgres;

