create function location_shelf_number_i(i_shelf_number integer, i_location_words character varying) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('locations_shelf_number_id_locations_shelf_number_seq');
        -- izvršimo INSERT stavek
        INSERT INTO locations_shelf_number(id_locations_shelf_number, shelf_number, location_words)
        VALUES (kljuc, i_shelf_number, location_words);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function location_shelf_number_i(integer, varchar) owner to postgres;

