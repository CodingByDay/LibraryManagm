create function countries_i(i_country character varying) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('countries_id_countries_seq');
        -- izvršimo INSERT stavek
        INSERT INTO countries(id_countries, country)
        VALUES (kljuc, i_country);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function countries_i(varchar) owner to postgres;

