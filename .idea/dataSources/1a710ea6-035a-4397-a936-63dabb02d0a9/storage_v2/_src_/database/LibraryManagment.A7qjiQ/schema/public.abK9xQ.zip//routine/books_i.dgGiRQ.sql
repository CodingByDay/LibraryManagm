create function books_i(i_isbn integer, i_name character varying, i_price integer, i_available boolean, i_id_category integer, i_id_publisher integer, i_id_location_shelf_number integer) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('books_id_books_seq');
        -- izvršimo INSERT stavek
        INSERT INTO books(id_books, "ISBN", name, price, available, id_category, id_publisher, id_location_shelf_number)
        VALUES (kljuc, i_isbn, i_name, i_price, i_available, i_id_category, i_id_publisher, i_id_location_shelf_number);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function books_i(integer, varchar, integer, boolean, integer, integer, integer) owner to postgres;

