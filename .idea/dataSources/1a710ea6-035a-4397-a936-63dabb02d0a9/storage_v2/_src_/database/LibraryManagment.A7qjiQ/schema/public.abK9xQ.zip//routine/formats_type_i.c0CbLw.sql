create function formats_type_i(i_format character varying) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('formats_type_id_formats_type_seq');
        -- izvršimo INSERT stavek
        INSERT INTO formats_type(id_formats_type, format)
        VALUES (kljuc, i_format);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function formats_type_i(varchar) owner to postgres;

