create function authors_i(i_name character varying, i_surname character varying, i_date_of_birth date) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('authors_id_authors_seq');
        -- izvršimo INSERT stavek
        INSERT INTO authors(id_authors, name, surname, date_of_birth)
        VALUES (kljuc, i_name, i_surname, i_date_of_birth);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function authors_i(varchar, varchar, date) owner to postgres;

