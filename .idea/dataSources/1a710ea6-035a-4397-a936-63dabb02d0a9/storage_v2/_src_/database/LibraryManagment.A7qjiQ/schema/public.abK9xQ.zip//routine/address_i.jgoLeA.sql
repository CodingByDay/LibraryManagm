create function address_i(i_street character varying, i_id_zipcodes integer, i_id_country integer) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('address_id_address_seq');
        -- izvršimo INSERT stavek
        INSERT INTO address(id_address, street, id_zipcodes, id_countries)
        VALUES (kljuc, i_street, i_id_zipcodes, i_id_country);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function address_i(varchar, integer, integer) owner to postgres;

