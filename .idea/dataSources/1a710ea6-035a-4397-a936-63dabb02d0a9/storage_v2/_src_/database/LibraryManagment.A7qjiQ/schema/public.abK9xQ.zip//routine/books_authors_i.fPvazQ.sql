create function books_authors_i(i_id_book integer, i_id_authors integer) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('address_id_address_seq');
        -- izvršimo INSERT stavek
        INSERT INTO books_authors
        VALUES (kljuc, i_id_book, i_id_authors);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function books_authors_i(integer, integer) owner to postgres;

