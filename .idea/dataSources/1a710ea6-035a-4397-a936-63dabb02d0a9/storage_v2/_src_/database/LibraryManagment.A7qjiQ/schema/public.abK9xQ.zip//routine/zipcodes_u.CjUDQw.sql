create function zipcodes_u(i_id_zipcodes integer, i_zipcode character varying, i_city character varying) returns integer
    language plpgsql
as
$$
BEGIN
    -- izvršimo UPDATE stavek
    UPDATE zipcodes
        SET
            zipcode = i_zipcode,
            city = i_city
        WHERE id_zipcodes = "i_id_zipcodes";
    RETURN i_id_zipcodes;
    -- prestrezanje možnih izjem
    EXCEPTION
        WHEN integrity_constraint_violation THEN
            RAISE EXCEPTION 'Napaka ... referenčna integriteta.';
        WHEN not_null_violation THEN
            RAISE EXCEPTION 'Napaka ... ni zahtevane vrednosti polja.';
        WHEN foreign_key_violation THEN
            RAISE EXCEPTION 'Napaka ... neustrezna vrednost tujega ključa.';
        WHEN unique_violation THEN
            RAISE EXCEPTION 'Napaka ... ni enolične vrednosti polja.';
        WHEN check_violation THEN
            RAISE EXCEPTION 'Napaka ... validacijsko pravilo.';
        -- v primeru ostalih napak
        WHEN others THEN
            RAISE EXCEPTION 'Napaka ...';
END;
$$;

alter function zipcodes_u(integer, varchar, varchar) owner to postgres;

