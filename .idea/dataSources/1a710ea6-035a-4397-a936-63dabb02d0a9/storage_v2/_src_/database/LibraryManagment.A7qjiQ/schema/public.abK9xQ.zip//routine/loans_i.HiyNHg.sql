create function loans_i(i_date date, i_id_account_staff integer, i_id_account_member integer) returns integer
    language plpgsql
as
$$
DECLARE
        kljuc INTEGER;
        BEGIN-- uporabimo naslednjo vrednost
        kljuc = nextval('address_id_address_seq');
        -- izvršimo INSERT stavek
        INSERT INTO loans
        VALUES (kljuc, i_date, i_id_account_staff, i_id_account_member);-- vrnemo vrednost ključa dodane oz. vstavljene vrstice
        RETURN kljuc;
        END;
$$;

alter function loans_i(date, integer, integer) owner to postgres;

